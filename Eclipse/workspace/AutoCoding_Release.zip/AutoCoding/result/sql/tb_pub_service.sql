delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SUBSIDY_REPORT') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (4048, 'DCCrmQuerySubsidyReport', 'QUERY_SUBSIDY_REPORT', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SUBSIDY_REPORT') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (4048, 'DCCrmQuerySubsidyReport', 'QUERY_SUBSIDY_REPORT', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SUBSIDY_REPORT') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (4048, 'DCCrmQuerySubsidyReport', 'QUERY_SUBSIDY_REPORT', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SUBSIDY_REPORT') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (4048, 'DCCrmQuerySubsidyReport', 'QUERY_SUBSIDY_REPORT', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SUBSIDY_REPORT') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (4048, 'DCCrmQuerySubsidyReport', 'QUERY_SUBSIDY_REPORT', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SUBSIDY_REPORT') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (4048, 'DCCrmQuerySubsidyReport', 'QUERY_SUBSIDY_REPORT', null, 'libcrmcommqry.so', null, '0', '0');


