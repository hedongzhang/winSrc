delete from tb_pub_paramcodedetail t where t.CLASS_ID=2487 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '1', '6', 0, 'BILLING_CYCLE_BEGIN', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '2', '6', 0, 'BILLING_CYCLE_END', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '3', '5', 64, 'PRE_RULE_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '4', '5', 1024, 'PRE_RULE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '5', '5', 64, 'OBJ_TYPE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '6', '5', 512, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '7', '5', 64, 'DEVELOPER_CODE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '8', '5', 64, 'STAFF_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '9', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '10', '5', 64, 'CUST_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '11', '5', 64, 'ACCT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '12', '5', 64, 'ACCT_NBR', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2487 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '1', '6', 0, 'BILLING_CYCLE_BEGIN', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '2', '6', 0, 'BILLING_CYCLE_END', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '3', '5', 64, 'PRE_RULE_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '4', '5', 1024, 'PRE_RULE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '5', '5', 64, 'OBJ_TYPE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '6', '5', 512, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '7', '5', 64, 'DEVELOPER_CODE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '8', '5', 64, 'STAFF_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '9', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '10', '5', 64, 'CUST_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '11', '5', 64, 'ACCT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '12', '5', 64, 'ACCT_NBR', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2487 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '1', '6', 0, 'BILLING_CYCLE_BEGIN', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '2', '6', 0, 'BILLING_CYCLE_END', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '3', '5', 64, 'PRE_RULE_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '4', '5', 1024, 'PRE_RULE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '5', '5', 64, 'OBJ_TYPE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '6', '5', 512, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '7', '5', 64, 'DEVELOPER_CODE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '8', '5', 64, 'STAFF_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '9', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '10', '5', 64, 'CUST_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '11', '5', 64, 'ACCT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '12', '5', 64, 'ACCT_NBR', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2487 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '1', '6', 0, 'BILLING_CYCLE_BEGIN', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '2', '6', 0, 'BILLING_CYCLE_END', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '3', '5', 64, 'PRE_RULE_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '4', '5', 1024, 'PRE_RULE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '5', '5', 64, 'OBJ_TYPE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '6', '5', 512, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '7', '5', 64, 'DEVELOPER_CODE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '8', '5', 64, 'STAFF_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '9', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '10', '5', 64, 'CUST_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '11', '5', 64, 'ACCT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '12', '5', 64, 'ACCT_NBR', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2487 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '1', '6', 0, 'BILLING_CYCLE_BEGIN', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '2', '6', 0, 'BILLING_CYCLE_END', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '3', '5', 64, 'PRE_RULE_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '4', '5', 1024, 'PRE_RULE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '5', '5', 64, 'OBJ_TYPE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '6', '5', 512, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '7', '5', 64, 'DEVELOPER_CODE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '8', '5', 64, 'STAFF_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '9', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '10', '5', 64, 'CUST_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '11', '5', 64, 'ACCT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '12', '5', 64, 'ACCT_NBR', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2487 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '1', '6', 0, 'BILLING_CYCLE_BEGIN', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '2', '6', 0, 'BILLING_CYCLE_END', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '3', '5', 64, 'PRE_RULE_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '4', '5', 1024, 'PRE_RULE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '5', '5', 64, 'OBJ_TYPE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '6', '5', 512, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '7', '5', 64, 'DEVELOPER_CODE', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '8', '5', 64, 'STAFF_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '9', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '10', '5', 64, 'CUST_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '11', '5', 64, 'ACCT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2487, '0', '12', '5', 64, 'ACCT_NBR', null, '550');

