/*
 * DCCrmQuerySubsidyReport.h
 *
 *  Created on: 2015��7��22��
 *      Author: HDZhang
 */

#ifndef DCCRMQUERYSUBSIDYREPORT_H_
#define DCCRMQUERYSUBSIDYREPORT_H_

#include "DCAtomService.h"
#include "DCServiceMacro.h"
#include "DCCrmDBAgent.h"
#include "DCCommService.h"

CRM_NAMESPACE_BEGIN(svc)

#define QUERY_SUBSIDY_REPORT_DEF 2487

class DCCrmQuerySubsidyReport : public DCAtomService
{
	DYN_CLASS_DECLARE(DCCrmQuerySubsidyReport)
public:
	DCCrmQuerySubsidyReport(const char* clsName="DCCrmQuerySubsidyReport");
	~DCCrmQuerySubsidyReport(){}
	int GetInputParam(DCObject* pBuffer);
	int BusinessProcess();
	int SetOutputParam(DCObject* pBuffer);
	int InitDBAgent(DCCrmDBAgent* pDBAgent, long nClassId, bool bReply, long nLocLatnId, long nTabLatnId,string extraSQL);

protected:
	struct STQuerySubsidyReportIn
	{
		char ACCT_NBR[64];
		char PRE_RULE_ID[64];
		char ACCEPT_USER[64];
		char CUST_ID[64];
		char RULE_TYPE[64];
		char ACCEPT_START_TIME[64];
		char ACCEPT_END_TIME[64];
		long LATN_ID;

	};

	struct STQuerySubsidyReportOut
	{
		long BILLING_CYCLE_BEGIN;
		long BILLING_CYCLE_END;
		char PRE_RULE_ID[64];
		char PRE_RULE_NAME[1024];
		char OBJ_TYPE[64];
		char DEVELOPER[512];
		char DEVELOPER_CODE[64];
		char STAFF_ID[64];
		char CUST_NAME[64];
		char CUST_ID[64];
		char ACCT_NAME[64];
		char ACCT_NBR[64];

	};
private:
	list<STQuerySubsidyReportIn> l_QuerySubsidyReportIn;
	list<STQuerySubsidyReportOut> l_QuerySubsidyReportOut;
};

CRM_NAMESPACE_END()

#endif /* DCCRMQUERYSUBSIDYREPORT_H_ */

