/*
 * main.cpp
 *
 *  Created on: 2014年12月14日
 *      Author: HDZhang
 */

#include"ACConfManager.h"
#include"ACService.h"
#include"ACManager.h"
#include<memory.h>
#include<map>

using namespace n_acmanager;
using namespace std;

int main(void) {

	ACManager acManager;

	return 0;
}



