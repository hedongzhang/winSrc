delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('QUERY_SJD_ORDER_DETAIL') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (67890, 'DCCrmQuerySjdOrderDetail', 'QUERY_SJD_ORDER_DETAIL', null, 'libcrmcommqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


delete from tb_pub_service t where t.OUTER_SVC_NAME in ('PAY_ONCE_ITEM_REQ_TYPE1') ;

insert into tb_pub_service (SVC_ID, INNER_SVC_NAME, OUTER_SVC_NAME, INVERSE_SVC_CODE, OWNER_DLL_NAME, SVC_DESC, TSC_FLAG, RULE_FLAG)
values (12345, 'DCCrmPayOnceItemReqType1', 'PAY_ONCE_ITEM_REQ_TYPE1', null, 'libcrmcommonqry.so', null, '0', '0');


