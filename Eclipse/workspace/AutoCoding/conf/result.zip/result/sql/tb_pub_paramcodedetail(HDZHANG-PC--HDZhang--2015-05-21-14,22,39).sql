delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2458, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

delete from tb_pub_paramcodedetail t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '1', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '1', '6', 0, 'ORDER_ID', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '2', '5', 64, 'CUST_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '3', '5', 64, 'CERT_NUMBER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '4', '5', 64, 'CERTI_TYPE_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '5', '5', 64, 'CONTACT_NAME', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '6', '5', 64, 'CONTACT_TEL', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '7', '5', 64, 'DEVELOPER', null, '550');

insert into tb_pub_paramcodedetail (CLASS_ID, PARAM_TYPE, ORDER_ID, VALUE_TYPE, VALUE_LENGTH, FIELD_NAME, VALUE, GROUP_ID)
values (2574, '0', '8', '5', 2048, 'SALE_ORDER_DESC', null, '550');

