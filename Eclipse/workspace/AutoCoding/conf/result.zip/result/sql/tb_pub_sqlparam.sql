delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2458 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2458, 'QUERY_SJD_ORDER_DETAIL', '
select a.sale_order_id,
       b.cust_name,
       b.CERT_NUMBER,
       c.certi_type_name,
       b.contact_name,
       b.contact_tel,
       a.developer || ''['' || a.developer_code || '']'' developer,
       a.sale_order_desc
  from crm_sale.SALE_MARKET_INST_P_{[LATN_ID:%ld]} a,
       crm_sale.sale_cust_p_{[LATN_ID:%ld]}        b,
       tb_pty_pty_certif_type_ref      c
 where a.sale_order_id = b.sale_order_id
   and b.CERT_TYPE = c.certi_type_id
   and a.sale_order_id = :order_id
 ', '1', null, 'QUERY_SJD_ORDER_DETAIL', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


delete from tb_pub_sqlparam t where t.CLASS_ID=2574 and t.GROUP_ID in ('550') ;

insert into tb_pub_sqlparam (CLASS_ID, CLASS_NAME, SQL_TEXT, DB_TYPE, DB_LINK, SERVER_NAME, PROCESS_ID, COL_COUNT, BIND_COUNT, GROUP_ID, SQL_DESC)
values (2574, 'PAY_ONCE_ITEM_REQ_TYPE1', '
SELECT A.SALE_ORDER_ID,
B.SALE_ITEM_ID,
A.STATUS_CD,
A.CUST_ID,
(SELECT Z.CUST_NAME FROM SALE_CUST_P_{[LATN_ID:%ld]} Z WHERE Z.CUST_ID = A.CUST_ID and Z.eff_state =1 and rownum = 1) CUST_NAME,
A.ACC_NBR,
(SELECT Y.PROD_OFFER_NAME FROM PROD_OFFER Y WHERE Y.PROD_OFFER_ID = A.OFFER_ID) OFFER_NAME,
DECODE(A.CHARGE_STATUS,''100002'',''已缴费'',''未缴费'') IF_CHARGED,
A.STATUS_CD STATUSA_CD,
getCodeName(''sale_order_inst_p_#'',
''status_cd'',
''sale_order_inst_p_#'',
A.status_cd) STATUS_NAME,
TO_CHAR(A.CREATE_DATE, ''yyyy-mm-dd hh24:mi:ss'') ACCEPT_TIME,
A.EXT_SYSTEM,
getCodeName(''sale_order_inst_p_#'',
''ext_system'',
''sale_order_inst_p_#'',
A.ext_system) EXT_SYSTEM_NAME,
A.SYSTEM_USER_ID EMPEE_ID,
I.STAFF_NAME EMPEE_NAME,
A.DEVELOPER
||''[''
||A.DEVELOPER_CODE
||''][''
||
(SELECT Z.DEPT_NAME
FROM TB_PTY_DEVELOPER_DEPT Z
WHERE A.DEVELOP_DEPARTMENT = Z.DEPT_ID
)
||'']'' DEVELOPER_NAME,
ROUND(TO_NUMBER((SYSDATE-NVL(A.STATUS_DATE,A.CREATE_DATE)))*24) CONSUME_TIME,
'''' IS_ERROR,
'''' ERROE_MSG,
''2'' ORDER_TYPE,
B.SERVICE_OFFER_ID,
(SELECT MIN(S.SERVICE_OFFER_NAME) FROM SERVICE_OFFER S WHERE S.SERVICE_OFFER_ID = B.SERVICE_OFFER_ID) SERVICE_OFFER_NAME,
A.COMMON_REGION_ID,
(SELECT REGION_NAME FROM COMMON_REGION WHERE COMMON_REGION_ID =A.COMMON_REGION_ID) REGION_NAME,
A.claim_person,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee
where empee_id = A.claim_person),
A.system_user_id,
(select empee_acct || ''['' || empee_name || '']''
from tb_pty_empee m
where m.empee_id =
A.system_user_id)
FROM SALE_MARKET_INST_P_{[LATN_ID:%ld]} A,
SALE_ORDER_ITEM_P_{[LATN_ID:%ld]} B,
SYSTEM_USER I
WHERE A.SALE_ORDER_ID  = B.SALE_ORDER_ID
AND B.SALE_ITEM_CD   IN (''1200'', ''1000'',''1100'')
AND A.SYSTEM_USER_ID         = I.STAFF_ID(+)
AND A.LATN_ID         = :LATN_ID
AND B.MAIN_FLAG       = ''1''
AND B.EFF_STATE = ''1''
 ', '1', null, 'PAY_ONCE_ITEM_REQ_TYPE1', 1, 8, 1, '550', '');


